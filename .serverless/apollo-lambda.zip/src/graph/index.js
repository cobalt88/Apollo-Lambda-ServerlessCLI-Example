import { typeDefs } from "./typeDefs.js";
import { Query } from "./resolvers.js";

export const Resolvers = Query;
export const TypeDefs = typeDefs;
